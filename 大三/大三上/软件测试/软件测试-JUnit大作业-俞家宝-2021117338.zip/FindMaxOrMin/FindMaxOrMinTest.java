package maxbao.homework;

import org.junit.Test;

import static org.junit.Assert.*;

public class FindMaxOrMinTest {
    FindMaxOrMin testing = new FindMaxOrMin();

    //测试 findMax()

    /**
     * 正数值数组的最大值
     */
    @Test
    public void testFindMaxWithPositiveValues() {
        int[] array = {1, 5, 3, 9, 2, 7};
        int max = testing.findMax(array);
        assertEquals(9, max);
    }

    /**
     * 负数值数组的最大值
     */
    @Test
    public void testFindMaxWithNegativeValues() {
        int[] array = {-1, -5, -3, -9, -2, -7};
        int max = testing.findMax(array);
        assertEquals(-1, max);
    }

    /**
     * 混合正负数值数组的最大值
     */
    @Test
    public void testFindMax() {
        int[] array = {-1, 5, -3, 9, -2, 7};
        int max = testing.findMax(array);
        assertEquals(9, max);
    }

    /**
     * 只包含一个元素的数组的最大值
     */
    @Test
    public void testFindMaxWithSingle() {
        int[] array = {5};
        int max = testing.findMax(array);
        assertEquals(5, max);
    }

    /**
     * 包含重复元素的数组的最大值
     */
    @Test
    public void testFindMaxWithDouble() {
        int[] array = {2, 5, 5, 5, 4};
        int max = testing.findMax(array);
        assertEquals(5, max);
    }

    /**
     * 空数组抛出异常的测试
     */
    @Test(expected = IllegalArgumentException.class)
    public void testFindMaxWithEmpty() {
        int[] array = {};
        testing.findMax(array);
    }

    // 测试 findMin()

    /**
     * 正数值数组的最小值
     */
    @Test
    public void testFindMinWithPositiveValues() {
        int[] array = {1, 5, 3, 9, 2, 7};
        int min = testing.findMin(array);
        assertEquals(1, min);
    }

    /**
     * 负数值数组的最小值
     */
    @Test
    public void testFindMinWithNegativeValues() {
        int[] array = {-1, -5, -3, -9, -2, -7};
        int min = testing.findMin(array);
        assertEquals(-9, min);
    }

    /**
     * 混合正负数值数组的最小值
     */
    @Test
    public void testFindMin() {
        int[] array = {-1, 5, -3, 9, -2, 7};
        int min = testing.findMin(array);
        assertEquals(-3, min);
    }

    /**
     * 只包含一个元素的数组的最小值
     */
    @Test
    public void testFindMinWithSingle() {
        int[] array = {5};
        int min = testing.findMin(array);
        assertEquals(5, min);
    }

    /**
     * 包含重复元素的数组的最小值
     */
    @Test
    public void testFindMinWithDouble() {
        int[] array = {-1, 5, 3, 5, -1};
        int min = testing.findMin(array);
        assertEquals(-1, min);
    }

    /**
     * 空数组抛出异常的测试
     */
    @Test(expected = IllegalArgumentException.class)
    public void testFindMinWithEmpty() {
        int[] array = {};
        testing.findMin(array);
    }
}