package maxbao.homework;

import org.junit.Test;

import static org.junit.Assert.*;

public class IsPrimeTest {
    IsPrime testing = new IsPrime();

    /**
     * 测试100以内是否为素数
     */
    @Test
    public void testIsPrime() {
        // 测试质数
        assertTrue(testing.isPrime(2));
        assertTrue(testing.isPrime(3));
        assertTrue(testing.isPrime(5));
        assertTrue(testing.isPrime(7));
        assertTrue(testing.isPrime(11));
        assertTrue(testing.isPrime(13));
        assertTrue(testing.isPrime(17));
        assertTrue(testing.isPrime(19));
        assertTrue(testing.isPrime(23));
        assertTrue(testing.isPrime(29));
        assertTrue(testing.isPrime(31));
        assertTrue(testing.isPrime(37));
        assertTrue(testing.isPrime(41));
        assertTrue(testing.isPrime(43));
        assertTrue(testing.isPrime(47));
        assertTrue(testing.isPrime(53));
        assertTrue(testing.isPrime(59));
        assertTrue(testing.isPrime(61));
        assertTrue(testing.isPrime(67));
        assertTrue(testing.isPrime(71));
        assertTrue(testing.isPrime(73));
        assertTrue(testing.isPrime(79));
        assertTrue(testing.isPrime(83));
        assertTrue(testing.isPrime(89));
        assertTrue(testing.isPrime(97));

        // 测试非质数
        assertFalse(testing.isPrime(1));
        assertFalse(testing.isPrime(4));
        assertFalse(testing.isPrime(6));
        assertFalse(testing.isPrime(8));
        assertFalse(testing.isPrime(9));
        assertFalse(testing.isPrime(10));
        assertFalse(testing.isPrime(12));
        assertFalse(testing.isPrime(14));
        assertFalse(testing.isPrime(15));
        assertFalse(testing.isPrime(16));
        assertFalse(testing.isPrime(18));
        assertFalse(testing.isPrime(20));
        assertFalse(testing.isPrime(21));
        assertFalse(testing.isPrime(22));
        assertFalse(testing.isPrime(24));
        assertFalse(testing.isPrime(25));
        assertFalse(testing.isPrime(26));
        assertFalse(testing.isPrime(27));
        assertFalse(testing.isPrime(28));
        assertFalse(testing.isPrime(30));
        assertFalse(testing.isPrime(32));
        assertFalse(testing.isPrime(33));
        assertFalse(testing.isPrime(34));
        assertFalse(testing.isPrime(35));
        assertFalse(testing.isPrime(36));
        assertFalse(testing.isPrime(38));
        assertFalse(testing.isPrime(39));
        assertFalse(testing.isPrime(40));
        assertFalse(testing.isPrime(42));
        assertFalse(testing.isPrime(44));
        assertFalse(testing.isPrime(45));
        assertFalse(testing.isPrime(46));
        assertFalse(testing.isPrime(48));
        assertFalse(testing.isPrime(49));
        assertFalse(testing.isPrime(50));
        assertFalse(testing.isPrime(51));
        assertFalse(testing.isPrime(52));
        assertFalse(testing.isPrime(54));
        assertFalse(testing.isPrime(55));
        assertFalse(testing.isPrime(56));
        assertFalse(testing.isPrime(57));
        assertFalse(testing.isPrime(58));
        assertFalse(testing.isPrime(60));
        assertFalse(testing.isPrime(62));
        assertFalse(testing.isPrime(63));
        assertFalse(testing.isPrime(64));
        assertFalse(testing.isPrime(65));
        assertFalse(testing.isPrime(66));
        assertFalse(testing.isPrime(68));
        assertFalse(testing.isPrime(69));
        assertFalse(testing.isPrime(70));
        assertFalse(testing.isPrime(72));
        assertFalse(testing.isPrime(74));
        assertFalse(testing.isPrime(75));
        assertFalse(testing.isPrime(76));
        assertFalse(testing.isPrime(77));
        assertFalse(testing.isPrime(78));
        assertFalse(testing.isPrime(80));
        assertFalse(testing.isPrime(81));
        assertFalse(testing.isPrime(82));
        assertFalse(testing.isPrime(84));
        assertFalse(testing.isPrime(85));
        assertFalse(testing.isPrime(86));
        assertFalse(testing.isPrime(87));
        assertFalse(testing.isPrime(88));
        assertFalse(testing.isPrime(90));
        assertFalse(testing.isPrime(91));
        assertFalse(testing.isPrime(92));
        assertFalse(testing.isPrime(93));
        assertFalse(testing.isPrime(94));
        assertFalse(testing.isPrime(95));
        assertFalse(testing.isPrime(96));
        assertFalse(testing.isPrime(98));
        assertFalse(testing.isPrime(99));
    }
}