import json
from datetime import datetime

from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt

from rules.DealBySubmit import useHeartpy
from django.http import HttpResponse

userInfo = {}
measures = {}
image = ""


@csrf_exempt
def welcome(request):
    return render(request, 'submit.html')


@csrf_exempt
def toReportPage(request):
    return render(request, 'reportPage.html', {'datetime':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'measures': measures, 'ecgImg': image, 'userInfo': userInfo})


@csrf_exempt
def toHistory(request):
    cookies = []
    all_cookies = request.COOKIES
    # 设置你想要统计的cookie前缀
    prefix = 'cookie'
    # 计算以特定前缀开头的cookie数量
    count = sum(1 for cookie_name in all_cookies.keys() if cookie_name.startswith(prefix))
    if count > 0:
        for i in range(count):
            cookie_name = prefix + str(i + 1)
            if cookie_name in all_cookies.keys():
                cookie = json.loads(all_cookies[cookie_name])
                cookies.append(cookie)
        return render(request, 'history.html', {'cookies': cookies})
    else:
        return render(request, 'history.html')


@csrf_exempt
def submit(request):
    global image, measures
    if request.method == 'POST':
        userInfo.update({
            'username': request.POST.get('username'),
            'sex': request.POST.get('sex'),
            'age': request.POST.get('age'),
            'height': request.POST.get('height'),
            'weight': request.POST.get('weight')
        })
        print(userInfo)
        image, measures = useHeartpy(request.FILES.get('files'))
        measures = {key: f'{value:.3f}' for key, value in measures.items()}
        ###
        ###
        response = redirect('report')
        # 获取请求中的数据
        datetime_val = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        # 构建 cookie 数据
        # 获取所有的cookie
        all_cookies = request.COOKIES

        # 设置你想要统计的cookie前缀
        prefix = 'cookie'
        # 计算以特定前缀开头的cookie数量
        count = sum(1 for cookie_name in all_cookies.keys() if cookie_name.startswith(prefix))
        cookie = {'datetime': datetime_val, 'userInfo': userInfo, 'measures': measures}
        cookie_name = "cookie" + str(count + 1)
        response.set_cookie(cookie_name, json.dumps(cookie), max_age=900)
        return response
    else:
        return render(request, 'submit.html')

# TODO: cookie存储是因为value太长，需要把base64换成本地存储，并考虑规定时间内删除
