import json
from datetime import datetime

from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
def demo1(re):
    response = redirect('hello')
    response.set_cookie('he', '111', max_age=3600)
    cookies = [{'datetime': 1, 'userInfo': 2, 'ecgValue': 3}, {'datetime': 4, 'userInfo': 5, 'ecgValue': 6}]
    response.set_cookie('cookies', cookies, max_age=3600)
    return response


@csrf_exempt
def welcome(re):
    hel = re.COOKIES.get('he')
    cookies = re.COOKIES.get('cookies')
    print(cookies)
    return render(re, 'demo.html', {'hel': hel})
