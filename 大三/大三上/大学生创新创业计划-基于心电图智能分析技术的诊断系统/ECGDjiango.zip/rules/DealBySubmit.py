import base64
from io import BytesIO
import numpy as np
import heartpy as hp
import matplotlib.pyplot as plt
from scipy import signal

num_samples_to_read = 65000  # 读取部分数据，可根据需要调整
image_start = 10000
image_end = 15000


def dealData(data):
    signal_data = np.frombuffer(data.read(), dtype=np.int16, count=num_samples_to_read)
    # 对信号进行滤波处理
    b, a = signal.butter(4, 0.1, 'low')  # 低通滤波器设计，截止频率为0.1
    filtered_signal = signal.filtfilt(b, a, signal_data)

    # 缩放信号
    scaled_signal = (filtered_signal - np.mean(filtered_signal)) / np.std(filtered_signal)

    # 从.hea文件中获取采样率
    sampling_rate = 125  # 降低采样率至100Hz，可根据实际情况调整

    # 使用HeartPy库进行数据处理
    working_data, measures = hp.process(scaled_signal, sampling_rate)
    return scaled_signal, measures


def drawImg(ecg):
    # 绘制图形
    plt.figure(figsize=(12, 4))
    plt.plot(ecg[image_start:image_end], label='Raw Data', color='gray')
    plt.xlabel('Time')
    plt.legend()
    plt.ylim(-5, 10)
    plt.grid(True)
    plt.savefig("filename24")
    return getBase64(plt)


def getBase64(image):
    # 获取图形的画布
    fig = image.gcf()
    fig.canvas.draw()

    # 获取画布的RGB数据
    image_data = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    image_data = image_data.reshape(fig.canvas.get_width_height()[::-1] + (3,))

    # 保存图形并关闭图形
    buffer = BytesIO()
    image.savefig(buffer, format='png')
    image.close()  # 关闭图形
    buffer.seek(0)

    # 添加base64头
    base64_with_header = 'data:image/png;base64,' + base64.b64encode(buffer.getvalue()).decode()
    return base64_with_header


def useHeartpy(data):
    ecgSignal, measures = dealData(data)
    return drawImg(ecgSignal),measures

