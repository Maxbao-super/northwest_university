import os
import numpy as np
import heartpy as hp
import matplotlib.pyplot as plt
from scipy import signal

# 设置文件路径
dat_filepath = '../Data/101.dat'  # 将'your_dat_file_path_here'替换为您的.dat文件路径

# 读取部分.dat文件数据
num_samples_to_read = 65000  # 读取部分数据，可根据需要调整
image_start = 10000
image_end = 15000

with open(dat_filepath, 'rb') as f:
    signal_data = np.fromfile(f, dtype=np.int16, count=num_samples_to_read)

# 对信号进行滤波处理
b, a = signal.butter(4, 0.1, 'low')  # 低通滤波器设计，截止频率为0.1
filtered_signal = signal.filtfilt(b, a, signal_data)

# 缩放信号
scaled_signal = (filtered_signal - np.mean(filtered_signal)) / np.std(filtered_signal)

# 从.hea文件中获取采样率
sampling_rate = 125  # 降低采样率至100Hz，可根据实际情况调整

# 使用HeartPy库进行数据处理
working_data, measures = hp.process(scaled_signal, sampling_rate)
print(measures)
# # 绘制ECG心电图片
# plt.figure(figsize=(12, 4))
# hp.plotter(working_data, measures)
# plt.show()
# 计算心率时间戳
heart_rate_ts = np.cumsum(measures['ibi'])

# 绘制仿真心电图
plt.figure(figsize=(12, 4))
plt.plot(scaled_signal[10000:15000], label='Raw Data', color='gray')
plt.xlabel('Time')
plt.title('Simulated ECG with Heart Rate Detection')
plt.legend()
plt.ylim(-5, 5)
plt.grid(True)
plt.show()
