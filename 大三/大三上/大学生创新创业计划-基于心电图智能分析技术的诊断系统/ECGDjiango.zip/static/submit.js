function showForm() {
    var manuInput = document.getElementById("manuInput");
    var autoInput = document.getElementById("autoInput");

    var inputArea = document.getElementById("inputArea");
// 清空容器中的内容
    inputArea.innerHTML = "";
    if (manuInput.checked) {
        inputArea.innerHTML = "<textarea id=\"inputData\" class=\"form-control\" placeholder=\"请输入标准心电数据\" name=\"files\"></textarea>";
    } else if (autoInput.checked) {
        inputArea.innerHTML = "<input type=\"file\" name=\"files\">";
    }
}

