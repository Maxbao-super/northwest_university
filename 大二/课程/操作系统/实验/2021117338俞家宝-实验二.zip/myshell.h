#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#define MAX_BUFFER 1024
#define MAX_ARGS 100

char cmd[MAX_BUFFER];
char tmp[MAX_ARGS];
char b = 'F';
char * p;
char* args[MAX_ARGS];
int bg;


char parsecmd(char * s) {
	if(!strcasecmp(s, "quite")) return 'T';
	else if(!strncasecmp(s, "cd", 2)) return 1;
	else if(!strncasecmp(s, "ls", 2)) return 2;
	else if(!strncasecmp(s, "dir", 2)) return 2;
	else if(!strncasecmp(s, "clr", 3)) return 3;
	else if(!strncasecmp(s, "env", 3)) return 4;
	else if(!strncasecmp(s, "help", 4)) return 5;
	else if(!strncasecmp(s, "echo", 4)) return 7;
	else if(!strncasecmp(s, "pause", 5)) return 6;
	else return 8;
}

void help(char* args[]) {
	system("more -5 ~/Desktop/shell/help.txt");
}


void parse(char* cmdline, char* args[], int* bg) {
	char* token;
	int i = 0;
	*bg = 0;
	token = strtok(cmdline, " \t\n");
	while (token != NULL && i < MAX_ARGS - 1) {
		if (strcmp(token, "&") == 0) {
			*bg = 1;
			break;
		}
		args[i++] = token;
		token = strtok(NULL, " \t\n");
	}
	args[i] = NULL;
}
void echo(char* args[]) {
	int i = 1;
	while (args[i] != NULL) {
		printf("%s ", args[i++]);
	}
	printf("\n");
}
