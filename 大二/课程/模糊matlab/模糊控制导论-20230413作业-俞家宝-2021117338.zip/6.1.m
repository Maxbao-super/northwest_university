clc;clear all;close all;
tic;
X=[0.2,0.1;0.4,0.3];
Y=[0.9,1;0,0.1];
Z=[0.1,0.7;0.2,1];
XC=1-X;
ZC=1-Z;
U=syn(Z,Y);V=syn(Y,X);
XCandU=min(XC,U);
ZCandV=min(ZC,V);
XCandU
ZCandV
toc;