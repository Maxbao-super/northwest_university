clc;clear all;close all;
tic;
R=[0.1,0.3;0.2,1];
S=[0.4,0.9;0.5,0.8];
T=[0,0.2;0.7,0.6];
SandT=min(S,T);
U=syn(T,S);
M=syn(R,S);
W=max(U,M);
V=syn(SandT,R);
V
W
toc;
