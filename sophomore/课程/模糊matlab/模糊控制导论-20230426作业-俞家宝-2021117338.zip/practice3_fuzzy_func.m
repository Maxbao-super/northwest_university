function X = fuzzy_func(A, B, C)
    X = max(A, min(1 - B, C));
end
