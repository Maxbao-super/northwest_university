clc;clear all;close all;
tic;
x=-4:0.001:9;
A=((x+4)/7).*(x>=-4 & x<3)+((9-x)/6).*(x>=3 & x<=9);
B=exp(-abs(x-2)/8);
AC=1-A;BC=1-B;
AnB=min(A,B);AuB=max(A,B);
AnAC=min(A,AC); AuAC=max(A,AC);
BnBC=min(B,BC); BuBC=max(B,BC);
%A & B
figure(1);
plot(x,A,'-green','LineWidth',1);
hold on;
plot(x,B,'--black','LineWidth',1);
axis([-4,9,0,1.05*max(max(A),max(B))]);
box off;
%AnB & AuB
figure(2);
plot(x,AnB,'-green','LineWidth',1);
hold on;
plot(x,AuB,'--black','LineWidth',1);
axis([-4,9,0,1.05*max(max(AnB),max(AuB))]);
box off;
%AnAC & AuAC
figure(3);
plot(x,AnAC,'-green','LineWidth',1);
hold on;
plot(x,AuAC,'--black','LineWidth',1);
axis([-4,9,0,1.05*max(max(AnAC),max(AuAC))]);
box off;
%BnBC & BuBC
figure(4);
plot(x,BnBC,'-green','LineWidth',1);
hold on;
plot(x,BuBC,'--black','LineWidth',1);
axis([-4,9,0,1.05*max(max(BnBC),max(BuBC))]);
box off;
toc;