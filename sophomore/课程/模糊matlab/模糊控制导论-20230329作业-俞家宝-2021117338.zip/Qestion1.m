clc;clear all;close all;
tic;
x=[-2,-1,0,1,2,3,4];
A=0.06*x.^2-0.24*x+0.27;
B=-0.11*x.^2+0.22*x+0.27;
%A
xminA=min(x);xmaxA=max(x);ymaxA=max(A);
figure(1);stem(x,A);
axis([xminA-0.2,xmaxA+0.5,0,1.05*ymaxA]);box off;
%B
xminB=min(x);xmaxB=max(x);ymaxB=max(B);
figure(2);stem(x,B);
axis([xminB-0.2,xmaxB+0.5,0,1.05*ymaxB]);box off;
%AC
AC=1-A;
xminAC=min(x);xmaxAC=max(x);ymaxAC=max(AC);
figure(3);stem(x,AC);
axis([xminAC-0.2,xmaxAC+0.5,0,1.05*ymaxAC]);box off;
%BC
BC=1-B;
xminBC=min(x);xmaxBC=max(x);ymaxBC=max(BC);
figure(4);stem(x,BC);
axis([xminBC-0.2,xmaxBC+0.5,0,1.05*ymaxBC]);box off;
%AnB
AnB=min(A,B);
xminAnB=min(x);xmaxAnB=max(x);ymaxAnB=max(AnB);
figure(5);stem(x,AnB);
axis([xminAnB-0.2,xmaxAnB+0.5,0,1.05*ymaxAnB]);box off;
%AuB
AuB=max(A,B);
xminAuB=min(x);xmaxAuB=max(x);ymaxAuB=max(AuB);
figure(6);stem(x,AuB);
axis([xminAuB-0.2,xmaxAuB+0.5,0,1.05*ymaxAuB]);box off;
toc;